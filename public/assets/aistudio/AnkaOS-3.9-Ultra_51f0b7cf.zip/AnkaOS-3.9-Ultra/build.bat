@echo off
chcp 65001 >nul
title AnkaOS 3.9 Ultra - Exe Derleme
setlocal
cd /d "%~dp0"

echo ============================================
echo   AnkaOS 3.9 Ultra - Derleme Basliyor
echo ============================================

REM 1) Python kontrol
where py >nul 2>nul && (set PY=py) || (where python >nul 2>nul && set PY=python)
if not defined PY (echo [HATA] Python bulunamadi. python.org'dan kurun. & pause & exit /b 1)

REM 2) PyInstaller kur
%PY% -m pip install --upgrade pyinstaller >nul

REM 3) Tek dosya exe uret (konsolsuz)
%PY% -m PyInstaller --onefile --noconsole --name "AnkaOS3.9Ultra" ^
  --add-data "src\web;web" src\main.py
if errorlevel 1 (echo [HATA] Derleme basarisiz. & pause & exit /b 1)

REM 4) C++ modulunu derle (g++ veya MSVC varsa)
set OUT=dist\AnkaOS 3.9 Ultra
mkdir "%OUT%" >nul 2>nul
where g++ >nul 2>nul && g++ -O2 -std=c++17 cpp\system_info.cpp -o "%OUT%\system_info.exe"
if not exist "%OUT%\system_info.exe" (
  where cl >nul 2>nul && cl /O2 /EHsc cpp\system_info.cpp /Fe:"%OUT%\system_info.exe" >nul
)

copy /y dist\AnkaOS3.9Ultra.exe "%OUT%\AnkaOS3.9Ultra.exe" >nul

REM 5) Otomatik zip
powershell -NoProfile -Command "Compress-Archive -Path '%OUT%' -DestinationPath 'dist\AnkaOS-3.9-Ultra.zip' -Force"

echo.
echo ============================================
echo   TAMAM!
echo   Klasor: %OUT%
echo   Zip   : dist\AnkaOS-3.9-Ultra.zip
echo ============================================
pause
