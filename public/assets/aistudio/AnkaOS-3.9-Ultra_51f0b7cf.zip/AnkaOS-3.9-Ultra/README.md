# AnkaOS 3.9 Ultra 🦅

Python (stdlib) + HTML/CSS/JS + C++ ile yazilmis, masaustu "mini-OS" arayuzlu uygulama.
PyInstaller ile **tek dosya exe** olarak derlenir; hedef PC'de **Python kurulu olmasina gerek yoktur**.

## Ozellikler
- Masaustu benzeri arayuz: suruklenebilir pencereler, saat, karanlik/aydinlik tema
- Hesap makinesi, not defteri (otomatik kayit, `~/.ankaos/notlar.txt`), sistem bilgisi
- Sistem bilgisinde once C++ modulu (`system_info.exe`) kullanilir, yoksa Python yedegi devreye girer

## Windows'ta exe uretmek icin
1. `build.bat` dosyasina cift tikla. (Python 3.9+ gereklidir, sadece derleme icin.)
2. Exe otomatik olarak `dist/AnkaOS 3.9 Ultra/` klasorune kopyalanir ve
   `dist/AnkaOS-3.9-Ultra.zip` olarak otomatik zip'lenir.
3. Zip'i istedigin PC'ye gotur, cikar, `AnkaOS3.9Ultra.exe`ye cift tikla.
   Python'suz calisir; C++ modulu `system_info.exe` yaninda durursa kullanilir.

## Notlar
- Arayuz varsayilan tarayicide acilir (yerel sunucu: 127.0.0.1).
- C++ modulu istege baglidir; olmasa da uygulama tam calisir.
