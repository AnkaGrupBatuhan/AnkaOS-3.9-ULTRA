// system_info.cpp - AnkaOS 3.9 Ultra C++ bilgi modulu
// Windows'ta derle:  g++ -O2 -std=c++17 system_info.cpp -o system_info.exe
#include <cstdio>
#include <thread>
#include <string>
#ifdef _WIN32
  #include <windows.h>
  #include <lmcons.h>
#else
  #include <unistd.h>
  #include <pwd.h>
#endif

static std::string json_escape(const std::string& s){
    std::string r; for(char c: s){ if(c=='"'||c=='\\'){r+='\\';} r+=c; } return r;
}

int main(){
    unsigned cores = std::thread::hardware_concurrency();
    std::string host="?", user="?";
#ifdef _WIN32
    char buf[MAX_COMPUTERNAME_LENGTH+1]; DWORD n=sizeof(buf);
    if(GetComputerNameA(buf,&n)) host=buf;
    char ub[UNLEN+1]; DWORD un=sizeof(ub);
    if(GetUserNameA(ub,&un)) user=ub;
#else
    char buf[256]; if(gethostname(buf,sizeof(buf))==0) host=buf;
    if(auto* p=getpwuid(getuid())) user=p->pw_name;
#endif
    std::printf("{\"helper\":\"c++\",\"cores\":%u,\"hostname\":\"%s\",\"user\":\"%s\"}\n",
                cores, json_escape(host).c_str(), json_escape(user).c_str());
    return 0;
}
