// AnkaOS 3.9 Ultra - masaustu mantigi
const $ = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);

// ---- Saat ----
setInterval(() => { $('#clock').textContent = new Date().toLocaleTimeString('tr-TR'); }, 500);

// ---- Tema ----
const themeBtn = $('#themeBtn');
if (localStorage.getItem('ankaos-theme') === 'light') document.body.classList.add('light');
function syncThemeIcon(){ themeBtn.textContent = document.body.classList.contains('light') ? '☀️' : '🌙'; }
themeBtn.onclick = () => {
  document.body.classList.toggle('light');
  localStorage.setItem('ankaos-theme', document.body.classList.contains('light') ? 'light' : 'dark');
  syncThemeIcon();
};
syncThemeIcon();

// ---- Pencere ac/kapat + surukle ----
let z = 10;
$$('.icon').forEach(ic => ic.onclick = () => {
  const w = $('#win-' + ic.dataset.app);
  w.classList.add('open'); w.style.zIndex = ++z;
  if (ic.dataset.app === 'sistem') loadSystem();
  if (ic.dataset.app === 'not') loadNotes();
});
$$('.close').forEach(b => b.onclick = e => e.target.closest('.window').classList.remove('open'));
$$('.window').forEach(w => {
  const bar = w.querySelector('.wbar');
  bar.addEventListener('mousedown', ev => {
    if (ev.target.tagName === 'BUTTON') return;
    const r = w.getBoundingClientRect(), dx = ev.clientX - r.left, dy = ev.clientY - r.top;
    w.style.zIndex = ++z;
    const mv = e => { w.style.left = (e.clientX - dx) + 'px'; w.style.top = (e.clientY - dy) + 'px'; };
    const up = () => { removeEventListener('mousemove', mv); removeEventListener('mouseup', up); };
    addEventListener('mousemove', mv); addEventListener('mouseup', up);
  });
});

// ---- Hesap makinesi ----
const disp = $('#calcDisplay');
$$('.keys button').forEach(b => b.onclick = () => {
  const k = b.dataset.k;
  if (k === 'C') disp.value = '0';
  else if (k === 'back') disp.value = disp.value.slice(0, -1) || '0';
  else if (k === '=') {
    try { disp.value = String(Function('"use strict";return (' + disp.value + ')')()); }
    catch { disp.value = 'Hata'; }
  }
  else disp.value = disp.value === '0' ? k : disp.value + k;
});

// ---- Not defteri ----
let noteTimer;
async function loadNotes() {
  const r = await fetch('/api/notes'); const d = await r.json();
  $('#notes').value = d.notes || '';
}
$('#notes').addEventListener('input', () => {
  clearTimeout(noteTimer);
  noteTimer = setTimeout(async () => {
    await fetch('/api/notes', {method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({notes: $('#notes').value})});
    $('#noteStatus').textContent = 'Kaydedildi ✓ ' + new Date().toLocaleTimeString('tr-TR');
  }, 600);
});

// ---- Sistem bilgisi ----
async function loadSystem() {
  const el = $('#sysInfo');
  try {
    const r = await fetch('/api/system'); const d = await r.json();
    const rows = [
      ['Uygulama', d.app + ' v' + d.version],
      ['Bilgi Modülü', d.helper === 'c++' ? 'C++ (yerel)' : 'Python (yedek)'],
      ['İşletim Sistemi', d.os + ' ' + d.os_version],
      ['Makine', d.machine], ['İşlemci', d.processor],
      ['CPU Çekirdek', d.cpu_count], ['Bilgisayar Adı', d.hostname],
      ['Kullanıcı', d.user],
      ['Disk (Toplam)', d.disk_total_gb + ' GB'], ['Disk (Kullanılan)', d.disk_used_gb + ' GB'],
    ];
    el.innerHTML = '<table>' + rows.map(r => `<tr><td>${r[0]}</td><td>${r[1]}</td></tr>`).join('') + '</table>';
  } catch { el.textContent = 'Bilgi alınamadı.'; }
}
