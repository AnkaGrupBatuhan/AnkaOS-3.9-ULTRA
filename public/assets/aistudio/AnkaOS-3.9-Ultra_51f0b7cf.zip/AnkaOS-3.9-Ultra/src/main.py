# -*- coding: utf-8 -*-
"""
AnkaOS 3.9 Ultra - Bagimsiz Masaustu Uygulamasi
Python (stdlib) + HTML/CSS/JS + istege bagli C++ yardimci modulu
PyInstaller ile exe'ye derlenir, Python kurulu olmayan PC'lerde calisir.
"""
import getpass
import json
import os
import platform
import shutil
import socket
import subprocess
import sys
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

APP_NAME = "AnkaOS 3.9 Ultra"
APP_VERSION = "3.9.0-ultra"

def resource_path(rel):
    """PyInstaller (--onefile) icin gomulu kaynak yolu."""
    if getattr(sys, "frozen", False):
        return os.path.join(sys._MEIPASS, rel)
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), rel)

def exe_dir():
    """Exe'nin oldugu klasor (onefile'da sys.executable)."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))

def data_dir():
    d = os.path.join(os.path.expanduser("~"), ".ankaos")
    os.makedirs(d, exist_ok=True)
    return d

NOTES_FILE = os.path.join(data_dir(), "notlar.txt")
CPP_HELPER = os.path.join(exe_dir(), "system_info.exe")

def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p

def system_info():
    """Once C++ yardimciyi dene, yoksa Python stdlib ile uret."""
    if os.path.exists(CPP_HELPER):
        try:
            out = subprocess.check_output([CPP_HELPER], timeout=5)
            return json.loads(out.decode("utf-8", "ignore"))
        except Exception:
            pass
    total, used, free = shutil.disk_usage("/" if os.name != "nt" else "C:\\")
    return {
        "os": platform.system(),
        "os_version": platform.version(),
        "machine": platform.machine(),
        "processor": platform.processor() or platform.machine(),
        "hostname": socket.gethostname(),
        "user": getpass.getuser(),
        "python": platform.python_version(),
        "cpu_count": os.cpu_count(),
        "ram_mb": None,
        "disk_total_gb": round(total / (1024**3), 2),
        "disk_used_gb": round(used / (1024**3), 2),
        "app": APP_NAME,
        "version": APP_VERSION,
        "helper": "c++" if os.path.exists(CPP_HELPER) else "python",
    }

MIME = {".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8",
        ".js": "application/javascript; charset=utf-8", ".png": "image/png",
        ".ico": "image/x-icon", ".json": "application/json"}

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):  # konsol sessiz
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False).encode("utf-8")
        elif isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        u = urlparse(self.path)
        path = u.path
        if path == "/api/system":
            return self._send(200, system_info())
        if path == "/api/notes":
            notes = ""
            if os.path.exists(NOTES_FILE):
                notes = open(NOTES_FILE, encoding="utf-8").read()
            return self._send(200, {"notes": notes})
        if path in ("/", "/index.html"):
            p = resource_path(os.path.join("web", "index.html"))
            return self._send(200, open(p, "rb").read(), "text/html; charset=utf-8")
        # statik dosyalar
        rel = path.lstrip("/")
        full = os.path.normpath(os.path.join(resource_path("web"), rel))
        if not full.startswith(os.path.abspath(resource_path("web"))):
            return self._send(403, {"error": "forbidden"})
        if os.path.isfile(full):
            ext = os.path.splitext(full)[1].lower()
            return self._send(200, open(full, "rb").read(), MIME.get(ext, "application/octet-stream"))
        return self._send(404, {"error": "not found"})

    def do_POST(self):
        u = urlparse(self.path)
        if u.path == "/api/notes":
            length = int(self.headers.get("Content-Length", 0))
            raw = self.rfile.read(length).decode("utf-8", "ignore")
            data = json.loads(raw or "{}")
            with open(NOTES_FILE, "w", encoding="utf-8") as f:
                f.write(data.get("notes", ""))
            return self._send(200, {"ok": True})
        self._send(404, {"error": "not found"})

def main():
    port = free_port()
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    url = f"http://127.0.0.1:{port}/"
    print(f"{APP_NAME} calisiyor: {url}")
    try:
        webbrowser.open(url)
    except Exception:
        pass
    # pencere kapaninca (Ctrl+C) sunucuyu durdur
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    server.shutdown()

if __name__ == "__main__":
    main()
