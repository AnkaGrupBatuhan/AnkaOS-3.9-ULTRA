#!/usr/bin/env bash
# Linux icin derleme (Windows exe DEGILDIR)
set -e
cd "$(dirname "$0")"
python3 -m pip install --upgrade pyinstaller
python3 -m PyInstaller --onefile --noconsole --name "AnkaOS3.9Ultra" --add-data "src/web:web" src/main.py
g++ -O2 -std=c++17 cpp/system_info.cpp -o system_info
OUT="dist/AnkaOS 3.9 Ultra"
mkdir -p "$OUT"
cp dist/AnkaOS3.9Ultra "$OUT/AnkaOS3.9Ultra"
cp system_info "$OUT/"
(cd dist && zip -qr "AnkaOS-3.9-Ultra-Linux.zip" "AnkaOS 3.9 Ultra")
echo "Tamam: $OUT"
